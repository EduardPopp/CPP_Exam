# epitech_cpp_subject
This repository story all EPITECH's cpp pool 2018 (subject and header)

Feel free too open an issue if something is missing !
